# CoreBound Magnet

adds a magnet this pulls items towards the player. as seen in many modded packs but in a vanilla datapack.

## Development Notes
Some ideas and programming assistance were generated with the help of AI tools (ChatGPT) for briainstorming and function logic. All code was tested, intergrated and reviewed manually. 

## Resources
https://vanillatweaks.net/

https://www.gamergeeks.net/apps/minecraft

https://misode.github.io/

https://chatgpt.com/
